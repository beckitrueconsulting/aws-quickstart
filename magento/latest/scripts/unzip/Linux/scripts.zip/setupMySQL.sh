#!/bin/bash

cd /home/ec2-user/misc/scripts
source /home/ec2-user/misc/config.sh  
/usr/bin/node mysqlsetup.js